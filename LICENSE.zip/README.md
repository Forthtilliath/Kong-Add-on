# Kong Add-on
 
List of functionalities :
- Button moon/sun (top left) : enabling and disabling the dark mode on website
- Button unlock/lock (above the game) : lock your screen to prevent any mouse scrolling while you’re playing and keep your game in the center of the window. No more accidental scrolling while playing!
- Button user (above the game) : show the list of online players
- Select menu text size : adjust the text size in the chat (4 pixels to 20 pixels)
- Select menu brightness : adjust the brightnss of the game (50% to 150%, it means 50% darker to 50% brighter)
- Select menu volume :  adjust the volume of ping when someone post a message (0% to 100%)
